{
  "services": [
    {
      "name": "زيادة متابعين انستجرام",
      "icon": "https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png",
      "description": "زيادة متابعين حقيقيين ومتفاعلين لحسابك على انستجرام."
    },
    {
      "name": "لايكات فيسبوك",
      "icon": "https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282021%29.svg",
      "description": "لايكات حقيقية لمنشوراتك وصفحاتك على فيسبوك."
    },
    {
      "name": "مشاهدات يوتيوب",
      "icon": "https://upload.wikimedia.org/wikipedia/commons/4/42/YouTube_icon_%282021%29.svg",
      "description": "زيادة مشاهدات الفيديوهات لزيادة الأرباح."
    },
    {
      "name": "زيادة مشاهدات تيك توك",
      "icon": "https://upload.wikimedia.org/wikipedia/commons/b/ba/Tiktok_Logo.png",
      "description": "زيادة مشاهدات فيديوهاتك على تيك توك."
    }
  ],
  "requests": [],
  "alerts": []
}
